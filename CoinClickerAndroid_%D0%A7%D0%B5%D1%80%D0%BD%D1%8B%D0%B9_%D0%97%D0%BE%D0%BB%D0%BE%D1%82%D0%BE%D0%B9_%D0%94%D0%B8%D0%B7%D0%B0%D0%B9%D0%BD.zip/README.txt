COIN CLICKER — Android Studio project (Java)

Open the folder CoinClicker in Android Studio.
Wait for Gradle Sync.
Run on an Android emulator or a connected Android phone.

To build APK:
Build > Build Bundle(s) / APK(s) > Build APK(s)

Minimum SDK: 23
Compile SDK: 35

Game UI is built programmatically in MainActivity.java.
Progress is saved locally using SharedPreferences.
