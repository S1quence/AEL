const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', opened);
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
}));
const modal = document.getElementById('modal');
const selected = document.getElementById('selectedTournament');
document.querySelectorAll('[data-tournament]').forEach(button => button.addEventListener('click', () => {
  selected.textContent = button.dataset.tournament;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
}));
function closeModal() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
}
document.querySelector('.modal-close').addEventListener('click', closeModal);
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
document.getElementById('applyForm').addEventListener('submit', e => {
  e.preventDefault();
  const data = new FormData(e.target);
  const toast = document.getElementById('toast');
  toast.textContent = `Заявка для ${data.get('nickname')} подготовлена! Подключите сервер, чтобы получать реальные заявки.`;
  toast.classList.add('show');
  e.target.reset();
  closeModal();
  setTimeout(() => toast.classList.remove('show'), 4500);
});
const sections = [...document.querySelectorAll('main section[id]')];
const navLinks = [...document.querySelectorAll('.nav a')];
const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) navLinks.forEach(a => a.classList.toggle('active', a.getAttribute('href') === `#${entry.target.id}`));
  });
}, {rootMargin: '-35% 0px -55% 0px'});
sections.forEach(section => observer.observe(section));
