package com.example.coinclicker;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {
    private long coins = 0, totalCoins = 0;
    private int clicks = 0, clickPower = 1, income = 0, upgradeCount = 0;

    private SharedPreferences prefs;
    private LinearLayout root, content;
    private TextView balanceText, clickPowerText, incomeText;
    private ScrollView scrollView;

    private final int BG = Color.rgb(16, 16, 20);
    private final int CARD = Color.rgb(29, 29, 36);
    private final int GOLD = Color.rgb(255, 201, 40);
    private final int WHITE = Color.WHITE;
    private final int GRAY = Color.rgb(170, 170, 170);

    private final Handler handler = new Handler();
    private String currentScreen = "home";

    private final String[] upgradeNames = {
        "Сильный клик", "Мощный клик", "Суперклик",
        "Автокликер", "Мега автокликер"
    };
    private final String[] upgradeDescriptions = {
        "+1 монета за клик", "+5 монет за клик", "+10 монет за клик",
        "+1 монета в секунду", "+10 монет в секунду"
    };
    private final int[] upgradePrices = {50, 200, 1000, 500, 5000};
    private final int[] upgradeValues = {1, 5, 10, 1, 10};
    private final int[] upgradeCounts = new int[5];

    private final String[] questNames = {"Новичок", "Богач", "Покупатель", "Миллионер"};
    private final String[] questDescriptions = {
        "Нажми на монету 100 раз", "Заработай 1000 монет",
        "Купи 5 улучшений", "Заработай 10000 монет"
    };
    private final int[] questTargets = {100, 1000, 5, 10000};
    private final int[] questRewards = {50, 200, 300, 1000};
    private final boolean[] questCompleted = new boolean[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("CoinClickerSave", MODE_PRIVATE);
        loadGame();
        createInterface();
        showHome();

        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (income > 0) {
                    coins += income;
                    totalCoins += income;
                    updateBalance();
                    if ("quests".equals(currentScreen)) showQuests();
                    saveGame();
                }
                handler.postDelayed(this, 1000);
            }
        }, 1000);
    }

    private void createInterface() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(20), dp(20), dp(20), dp(10));
        setContentView(root);

        TextView title = createText("🪙 COIN CLICKER", 26, GOLD);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(55)));

        LinearLayout balanceCard = createCard();
        balanceText = createText("🪙 0", 32, GOLD);
        balanceText.setTypeface(null, Typeface.BOLD);
        balanceText.setGravity(Gravity.CENTER);
        TextView label = createText("Твой баланс", 14, GRAY);
        label.setGravity(Gravity.CENTER);
        balanceCard.addView(balanceText);
        balanceCard.addView(label);
        LinearLayout.LayoutParams balanceParams = new LinearLayout.LayoutParams(-1, dp(95));
        balanceParams.setMargins(0, dp(15), 0, dp(15));
        root.addView(balanceCard, balanceParams);

        scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scrollView.addView(content);
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout navigation = new LinearLayout(this);
        navigation.setOrientation(LinearLayout.HORIZONTAL);
        navigation.setGravity(Gravity.CENTER);

        Button homeButton = createButton("🪙 Клик");
        Button shopButton = createButton("🛒 Магазин");
        Button questButton = createButton("🎯 Квесты");
        homeButton.setOnClickListener(v -> showHome());
        shopButton.setOnClickListener(v -> showShop());
        questButton.setOnClickListener(v -> showQuests());

        navigation.addView(homeButton, new LinearLayout.LayoutParams(0, dp(55), 1));
        navigation.addView(shopButton, new LinearLayout.LayoutParams(0, dp(55), 1));
        navigation.addView(questButton, new LinearLayout.LayoutParams(0, dp(55), 1));
        root.addView(navigation);
    }

    private void showHome() {
        currentScreen = "home";
        content.removeAllViews();
        content.setGravity(Gravity.CENTER);

        TextView coin = createText("🪙", 100, GOLD);
        coin.setGravity(Gravity.CENTER);
        coin.setOnClickListener(v -> {
            coins += clickPower;
            totalCoins += clickPower;
            clicks++;
            updateBalance();
            saveGame();
            coin.animate().scaleX(0.90f).scaleY(0.90f).setDuration(70)
                .withEndAction(() -> coin.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();
        });
        content.addView(coin, new LinearLayout.LayoutParams(-1, dp(240)));

        clickPowerText = createText("За клик: +" + clickPower, 20, GOLD);
        clickPowerText.setGravity(Gravity.CENTER);
        content.addView(clickPowerText);

        incomeText = createText("Доход: " + income + " монет/сек", 16, GRAY);
        incomeText.setGravity(Gravity.CENTER);
        content.addView(incomeText);
    }

    private void showShop() {
        currentScreen = "shop";
        content.removeAllViews();
        content.setGravity(Gravity.TOP);
        content.addView(createText("🛒 Магазин улучшений", 24, GOLD));

        for (int i = 0; i < upgradeNames.length; i++) {
            final int index = i;
            long price = getUpgradePrice(i);
            LinearLayout card = createCard();

            card.addView(createText(upgradeNames[i], 18, WHITE));
            card.addView(createText(upgradeDescriptions[i], 14, GRAY));
            card.addView(createText("Куплено: " + upgradeCounts[i], 14, GRAY));

            Button buyButton = createButton("🪙 " + String.format(Locale.getDefault(), "%,d", price));
            buyButton.setEnabled(coins >= price);
            buyButton.setAlpha(coins >= price ? 1f : 0.5f);
            buyButton.setOnClickListener(v -> buyUpgrade(index));
            card.addView(buyButton);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.setMargins(0, dp(8), 0, dp(8));
            content.addView(card, params);
        }
    }

    private long getUpgradePrice(int index) {
        return (long) (upgradePrices[index] * Math.pow(1.5, upgradeCounts[index]));
    }

    private void buyUpgrade(int index) {
        long price = getUpgradePrice(index);
        if (coins < price) return;
        coins -= price;
        upgradeCounts[index]++;
        upgradeCount++;
        if (index <= 2) clickPower += upgradeValues[index];
        else income += upgradeValues[index];
        updateBalance();
        saveGame();
        showShop();
    }

    private void showQuests() {
        currentScreen = "quests";
        content.removeAllViews();
        content.setGravity(Gravity.TOP);
        content.addView(createText("🎯 Квесты", 24, GOLD));

        for (int i = 0; i < questNames.length; i++) {
            final int index = i;
            LinearLayout card = createCard();
            card.addView(createText(questNames[i], 18, WHITE));
            card.addView(createText(questDescriptions[i], 14, GRAY));

            long progress = getQuestProgress(i);
            card.addView(createText(progress + " / " + questTargets[i], 14, GOLD));

            Button rewardButton = createButton("🎁 " + questRewards[i] + " монет");
            boolean available = !questCompleted[i] && progress >= questTargets[i];
            rewardButton.setEnabled(available);
            rewardButton.setAlpha(available ? 1f : 0.5f);
            if (questCompleted[i]) rewardButton.setText("Выполнено ✓");
            rewardButton.setOnClickListener(v -> claimQuest(index));
            card.addView(rewardButton);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.setMargins(0, dp(8), 0, dp(8));
            content.addView(card, params);
        }
    }

    private long getQuestProgress(int index) {
        switch (index) {
            case 0: return clicks;
            case 1: return totalCoins;
            case 2: return upgradeCount;
            case 3: return totalCoins;
            default: return 0;
        }
    }

    private void claimQuest(int index) {
        if (questCompleted[index] || getQuestProgress(index) < questTargets[index]) return;
        coins += questRewards[index];
        questCompleted[index] = true;
        updateBalance();
        saveGame();
        showQuests();
    }

    private void updateBalance() {
        balanceText.setText("🪙 " + String.format(Locale.getDefault(), "%,d", coins));
        if (clickPowerText != null) clickPowerText.setText("За клик: +" + clickPower);
        if (incomeText != null) incomeText.setText("Доход: " + income + " монет/сек");
    }

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(15), dp(15), dp(15));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.rgb(55, 55, 60));
        card.setBackground(bg);
        return card;
    }

    private TextView createText(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setPadding(0, dp(5), 0, dp(5));
        return view;
    }

    private Button createButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.BLACK);
        button.setTextSize(14);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(GOLD));
        return button;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void saveGame() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong("coins", coins);
        editor.putLong("totalCoins", totalCoins);
        editor.putInt("clicks", clicks);
        editor.putInt("clickPower", clickPower);
        editor.putInt("income", income);
        editor.putInt("upgradeCount", upgradeCount);
        for (int i = 0; i < upgradeCounts.length; i++) editor.putInt("upgrade" + i, upgradeCounts[i]);
        for (int i = 0; i < questCompleted.length; i++) editor.putBoolean("quest" + i, questCompleted[i]);
        editor.apply();
    }

    private void loadGame() {
        coins = prefs.getLong("coins", 0);
        totalCoins = prefs.getLong("totalCoins", 0);
        clicks = prefs.getInt("clicks", 0);
        clickPower = prefs.getInt("clickPower", 1);
        income = prefs.getInt("income", 0);
        upgradeCount = prefs.getInt("upgradeCount", 0);
        for (int i = 0; i < upgradeCounts.length; i++) upgradeCounts[i] = prefs.getInt("upgrade" + i, 0);
        for (int i = 0; i < questCompleted.length; i++) questCompleted[i] = prefs.getBoolean("quest" + i, false);
    }

    @Override
    protected void onPause() {
        saveGame();
        super.onPause();
    }
}
